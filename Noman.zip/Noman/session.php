<?php
session_start();
$_SESSION['name']="nomi";


?>